import express from "express";
import { registerUser, loginUser } from "../controllers/authController.js";
import protect from '../middleware/authMiddleware.js';


const router = express.Router();

//Public Routes

// Register a new user
router.post('/register', registerUser);

//Log in an existing user
router.post('/login', loginUser);

// Get the details of the currently logged-in user

router.get('/me', protect, (req, res) => {
    res.status(200).json({
        success: true,
        user: req.user
    })
})

export default router;

