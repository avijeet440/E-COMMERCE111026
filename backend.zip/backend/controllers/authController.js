import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import generateToken from '../utils/generateToken.js';

//Register a new user;
const registerUser = async (req, res, next) => {
    try {
        //Get the user's details from the requwst body or frontend
        const { name, email, password } = req.body;
        //Check if the email is already registered
        const userExists = await User.findOne({ email });

        //Stop if the user already exists
        if (userExists) {
            return res.status(400).json({
                success: false,
                message: "User already exists"
            })
        }

        //Hash the password before saving it
        const hashedPassword = await bcrypt.hash(password, 10);

        //Create a new user
        const user = await User.create({
            name, email, password: hashedPassword
        })

        //Send a success response 


        res.status(201).json({
            success: true,
            message: 'User created successfully',
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        })

    } catch (error) {
        next(error);
    }
}

//Log in an existing user

const loginUser = async (req, res, next) => {
    try {
        //Get the login details from the frontend or request body

        const { email, password } = req.body;
        //Checks if the user exists in the database

        const user = await User.findOne({ email });
        //Stop if the user doesn't exist
        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            })
        }

        //Checks if the password is correct or not
        const isPasswordCorrect = await bcrypt.compare(password, user.password);
        //Stop if the password is incorrect

        if (!isPasswordCorrect) {
            return res.status(401).json({
                success: false,
                meassage: ' Invalid email or password'
            })
        }
        //Create a token after successful login and send it to the frontend

        const token = generateToken(user._id);
        res.status(200).json({
            success: true,
            message: "Login successful",
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        })

    } catch (error) {
        next(error)
    }
}

export {
    registerUser,
    loginUser
}